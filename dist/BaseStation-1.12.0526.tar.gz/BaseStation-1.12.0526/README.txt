QuadBaseStation
---------------

Dependencies:
pyqt4

Usage:
python main.py
